package com.dogsong.adapter.process;

/**
 * AbstractParamProcessor
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2023/6/29
 */
public abstract class AbstractParamProcessor implements ParamProcessor {
}
