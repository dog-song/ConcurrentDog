package com.dogsong.adapter.handler;

/**
 * 构造数据模型
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2023/6/29
 */
public interface BuildDataModel {

    void buildDataModel();

}
