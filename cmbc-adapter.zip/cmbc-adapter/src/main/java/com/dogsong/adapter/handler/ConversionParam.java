package com.dogsong.adapter.handler;

/**
 * ConversionHandler
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2023/6/29
 */
public interface ConversionParam {

    void transCodeConversion();

}
