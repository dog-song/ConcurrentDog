package com.dogsong.adapter.handler.impl;

import com.dogsong.adapter.handler.ValidateParam;
import org.springframework.stereotype.Service;

/**
 * ValidateParamHandler
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2023/6/30
 */
@Service
public class ValidateParamHandler implements ValidateParam {
    @Override
    public void validatedOriginParam() {

    }
}
