package com.dogsong.adapter.handler.impl;

import com.dogsong.adapter.handler.AbstractBuildDataModel;
import org.springframework.stereotype.Service;

/**
 * BuildDataModelHandler
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2023/6/29
 */
@Service
public class BuildDataModelHandler extends AbstractBuildDataModel {


    @Override
    protected void beforeSend() {

    }

    @Override
    protected void afterSend() {

    }
}
