package com.dogsong.adapter.handler;

/**
 * 构造数据模型-抽象类
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2023/6/29
 */
public abstract class AbstractBuildDataModel implements BuildDataModel {

    @Override
    public void buildDataModel() {
        beforeSend();

        afterSend();
    }

    protected abstract void beforeSend();

    protected abstract void afterSend();
}
