package com.dogsong.adapter.handler;

/**
 * TODO
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2023/6/29
 */
public interface MappingParam {

    void doMapping();

}
