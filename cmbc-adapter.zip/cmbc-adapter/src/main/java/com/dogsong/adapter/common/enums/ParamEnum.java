package com.dogsong.adapter.common.enums;

/**
 * TODO
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2023/6/29
 */
public enum ParamEnum {
}
