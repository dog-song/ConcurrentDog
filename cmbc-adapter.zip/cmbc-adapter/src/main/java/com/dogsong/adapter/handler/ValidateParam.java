package com.dogsong.adapter.handler;

/**
 * 校验参数
 *
 * @author <a href="mailto:dogsong99@gmail.com">dogsong</a>
 * @since 2023/6/29
 */
public interface ValidateParam {

    void validatedOriginParam();

}
